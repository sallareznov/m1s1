#ifndef _MI_SYSCALL_H_
#define _MI_SYSCALL_H_

#define SYSCALL_SWITCH_0 16
#define SYSCALL_SWITCH_1 17

#endif